#!/usr/bin/env python
from distutils.core import setup

setup(name='callback', version='1.0', description='results saving callback demo', author='omegaml',
      author_email='info@omegaml.io', url='http://omegaml.io', packages=['callback'], )
