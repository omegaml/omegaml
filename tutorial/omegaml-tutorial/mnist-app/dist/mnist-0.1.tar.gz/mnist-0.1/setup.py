from setuptools import setup, find_packages

setup(
    name='mnist',
    version='0.1',
    description='mnist app',
    author='omegaml',
    author_email='info@omegaml.io',
    url='http://omegaml.io',
    include_package_data=True,
    packages=find_packages(),
)
