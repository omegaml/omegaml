Mini-Batch Streaming
====================

See minibatch documentation at https://github.com/omegaml/minibatch