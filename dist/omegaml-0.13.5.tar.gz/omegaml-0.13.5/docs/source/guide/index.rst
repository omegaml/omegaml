User Guide
==========

.. toctree::
   :maxdepth: 2


   getstarted
   store_retrieve
   filterdf
   mdfapply
   modelstore
   lambda
   restapi
   custombackends
   runtimes
   buckets
   streaming
