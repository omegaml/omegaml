omega|ml
========

*omega|ml is the production and integration platform for data science
that scales from laptop to teams to enterprise. Batteries included.*

.. toctree::
   :maxdepth: 2

   quickstart
   guide/index
   admin/index
   devguide/index
   reference/index
   nb/index
   screenshots
