Development Guide
=================

.. toctree::
   :maxdepth: 2

   architecture
   custom
   metadata
   storage
   mixins
