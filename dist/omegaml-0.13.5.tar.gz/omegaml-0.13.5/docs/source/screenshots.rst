Screenshots
===========

Screenshots from the omega|ml Enterprise Edition

Dashboard
---------

.. image:: images/screenshots/dashboard.png
   :class: om-box

Notebook Online Editor & Report publishing
------------------------------------------

.. image:: images/screenshots/notebook.png
   :class: om-box

Integrated Online Help
----------------------

.. image:: images/screenshots/help.png
   :class: om-box

REST API documentation
----------------------

.. image:: images/screenshots/restapi.png
   :class: om-box