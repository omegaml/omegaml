Using omega|ml on private Spark Clusters
---------------------------------------

omega|ml can be installed on any machine of your preference following below steps:

* install omegaml using pip
* set env variables for mongodb and rabbitmq
* start celery worker
* import omegaml on start of pyspark