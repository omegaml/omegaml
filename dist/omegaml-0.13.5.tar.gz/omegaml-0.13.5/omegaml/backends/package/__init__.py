from .localpip import PythonPackageData
from .remotepip import PythonPipSourcedPackageData
