#!/usr/bin/env python
from distutils.core import setup

setup(name='helloworld', version='1.0', description='simple omegaml hello world script', author='omegaml',
      author_email='info@omegaml.io', url='http://omegaml.io', packages=['helloworld'], )
